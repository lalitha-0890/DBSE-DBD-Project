const express = require("express");
const path = require("path");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { db, run, get, all, initDatabase } = require("./database/database");
const { subjects } = require("./content");

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || "examprep-development-secret-change-me";
app.use(express.json({limit:"2mb"}));
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

function createToken(user){return jwt.sign({id:user.id,email:user.email,name:user.name},JWT_SECRET,{expiresIn:"7d"});}
function auth(req,res,next){
  const header=req.headers.authorization||""; const token=header.startsWith("Bearer ")?header.slice(7):null;
  if(!token) return res.status(401).json({message:"Please log in."});
  try{req.user=jwt.verify(token,JWT_SECRET);next();}catch{return res.status(401).json({message:"Your session has expired. Please log in again."});}
}

app.get("/api/health",(req,res)=>res.json({ok:true}));

app.post("/api/auth/register",async(req,res)=>{
  try{
    const {name,email,password}=req.body;
    const requestedUsername=String(req.body.username||"").trim();
    if(!name||!email||!password)return res.status(400).json({message:"All fields are required."});
    if(password.length<6)return res.status(400).json({message:"Password must contain at least 6 characters."});
    const cleanEmail=email.trim().toLowerCase();
    if(await get(`SELECT id FROM users WHERE email=?`,[cleanEmail]))return res.status(409).json({message:"An account with this email already exists."});
    const username=requestedUsername||name.trim().toLowerCase().replace(/[^a-z0-9]+/g,".").replace(/^\.|\.$/g,"").slice(0,24)||`student${Date.now()}`;
    const usernameExists=await get(`SELECT id FROM users WHERE username=?`,[username]);
    if(usernameExists)return res.status(409).json({message:"That username is already in use."});
    const hash=await bcrypt.hash(password,10);
    const result=await run(`INSERT INTO users(name,username,email,password_hash) VALUES(?,?,?,?)`,[name.trim(),username,cleanEmail,hash]);
    const user={id:result.id,name:name.trim(),username,email:cleanEmail};
    res.status(201).json({token:createToken(user),user});
  }catch(err){console.error(err);res.status(500).json({message:"Registration failed."});}
});
app.post("/api/auth/login",async(req,res)=>{
  try{
    const user=await get(`SELECT * FROM users WHERE email=?`,[String(req.body.email||"").trim().toLowerCase()]);
    if(!user||!(await bcrypt.compare(req.body.password||"",user.password_hash)))return res.status(401).json({message:"Invalid email or password."});
    const safe={id:user.id,name:user.name,username:user.username,email:user.email}; res.json({token:createToken(safe),user:safe});
  }catch(err){console.error(err);res.status(500).json({message:"Login failed."});}
});
app.get("/api/auth/me",auth,async(req,res)=>res.json({user:await get(`SELECT id,name,username,email,profile_pic,created_at,theme FROM users WHERE id=?`,[req.user.id])}));


app.get("/api/profile",auth,async(req,res)=>{
  try{
    const user=await get(`SELECT id,name,username,email,profile_pic,created_at,theme FROM users WHERE id=?`,[req.user.id]);
    if(!user)return res.status(404).json({message:"Profile not found."});
    res.json({user});
  }catch(err){console.error(err);res.status(500).json({message:"Could not load profile."});}
});

app.patch("/api/profile",auth,async(req,res)=>{
  try{
    const name=String(req.body.name||"").trim();
    const username=String(req.body.username||"").trim();
    const email=String(req.body.email||"").trim().toLowerCase();
    const profilePic=typeof req.body.profilePic==='string'?req.body.profilePic:null;
    if(!name||!username||!email)return res.status(400).json({message:"Name, username and email are required."});
    if(!/^[A-Za-z0-9_.-]{3,24}$/.test(username))return res.status(400).json({message:"Username must be 3–24 characters and use letters, numbers, dots, underscores or hyphens."});
    const emailOwner=await get(`SELECT id FROM users WHERE email=? AND id<>?`,[email,req.user.id]);
    if(emailOwner)return res.status(409).json({message:"That email is already in use."});
    const usernameOwner=await get(`SELECT id FROM users WHERE username=? AND id<>?`,[username,req.user.id]);
    if(usernameOwner)return res.status(409).json({message:"That username is already in use."});
    if(profilePic && profilePic.length>1200000)return res.status(400).json({message:"Profile picture is too large. Please choose a smaller image."});
    await run(`UPDATE users SET name=?,username=?,email=?,profile_pic=COALESCE(?,profile_pic) WHERE id=?`,[name,username,email,profilePic,req.user.id]);
    const user=await get(`SELECT id,name,username,email,profile_pic,created_at,theme FROM users WHERE id=?`,[req.user.id]);
    const safe={id:user.id,name:user.name,username:user.username,email:user.email};
    res.json({token:createToken(safe),user});
  }catch(err){console.error(err);res.status(500).json({message:"Could not update profile."});}
});

app.get("/api/settings",auth,async(req,res)=>{
  try{
    const user=await get(`SELECT theme FROM users WHERE id=?`,[req.user.id]);
    res.json({theme:user?.theme||"lavender"});
  }catch(err){console.error(err);res.status(500).json({message:"Could not load settings."});}
});

app.patch("/api/settings",auth,async(req,res)=>{
  try{
    const theme=String(req.body.theme||"lavender");
    if(!["lavender","light","dark"].includes(theme))return res.status(400).json({message:"Invalid theme."});
    await run(`UPDATE users SET theme=? WHERE id=?`,[theme,req.user.id]);
    res.json({theme});
  }catch(err){console.error(err);res.status(500).json({message:"Could not update settings."});}
});

app.post("/api/settings/password",auth,async(req,res)=>{
  try{
    const current=String(req.body.currentPassword||"");
    const next=String(req.body.newPassword||"");
    if(next.length<6)return res.status(400).json({message:"New password must contain at least 6 characters."});
    const user=await get(`SELECT password_hash FROM users WHERE id=?`,[req.user.id]);
    if(!user || !(await bcrypt.compare(current,user.password_hash)))return res.status(401).json({message:"Current password is incorrect."});
    const hash=await bcrypt.hash(next,10);
    await run(`UPDATE users SET password_hash=? WHERE id=?`,[hash,req.user.id]);
    res.json({message:"Password changed successfully."});
  }catch(err){console.error(err);res.status(500).json({message:"Could not change password."});}
});

app.delete("/api/settings/account",auth,async(req,res)=>{
  try{
    const confirm=String(req.body.confirm||"").trim().toUpperCase();
    if(confirm!=="DELETE")return res.status(400).json({message:"Type DELETE to confirm account deletion."});
    await run(`DELETE FROM users WHERE id=?`,[req.user.id]);
    res.json({message:"Account deleted."});
  }catch(err){console.error(err);res.status(500).json({message:"Could not delete account."});}
});

app.get("/api/performance",auth,async(req,res)=>{
  try{
    const userId=req.user.id;
    const subjectsRows=await all(`SELECT s.id,s.name,COALESCE(SUM(a.score),0) score,COALESCE(SUM(a.total),0) total,COUNT(a.id) attempts FROM subjects s LEFT JOIN quiz_attempts a ON a.subject_id=s.id AND a.user_id=? AND a.completed_at IS NOT NULL GROUP BY s.id ORDER BY s.id`,[userId]);
    const subjects=subjectsRows.map(s=>({...s,accuracy:s.total?Math.round(s.score/s.total*100):0}));
    const overall=await get(`SELECT COALESCE(SUM(score),0) score,COALESCE(SUM(total),0) total,COUNT(*) attempts FROM quiz_attempts WHERE user_id=? AND completed_at IS NOT NULL`,[userId]);
    const passed=await get(`SELECT COUNT(*) count FROM quiz_attempts WHERE user_id=? AND completed_at IS NOT NULL AND score>=8`,[userId]);
    const failed=await get(`SELECT COUNT(*) count FROM quiz_attempts WHERE user_id=? AND completed_at IS NOT NULL AND score<8`,[userId]);
    const concepts=await all(`SELECT q.concept,COUNT(*) wrong_count FROM attempt_answers aa JOIN quiz_attempts a ON a.id=aa.attempt_id JOIN questions q ON q.id=aa.question_id WHERE a.user_id=? AND aa.is_correct=0 GROUP BY q.concept ORDER BY wrong_count DESC LIMIT 6`,[userId]);
    const good=subjects.filter(s=>s.total&&s.accuracy>=75).sort((a,b)=>b.accuracy-a.accuracy);
    const work=subjects.filter(s=>s.total&&s.accuracy<75).sort((a,b)=>a.accuracy-b.accuracy);
    res.json({subjects,overall:{accuracy:overall.total?Math.round(overall.score/overall.total*100):0,attempts:overall.attempts,questions:overall.total},quizOutcome:{passed:passed.count,failed:failed.count},good,work,concepts});
  }catch(err){console.error(err);res.status(500).json({message:"Could not load performance analysis."});}
});

app.get("/api/subjects",auth,async(req,res)=>{
  const rows=await all(`SELECT id,name,description,icon FROM subjects ORDER BY id`);
  const result=[];
  for(const s of rows){
    const topics=await all(`SELECT t.id,t.name,t.slug,t.subtitle,COUNT(q.id) AS question_count FROM topics t LEFT JOIN questions q ON q.topic_id=t.id WHERE t.subject_id=? GROUP BY t.id ORDER BY t.id`,[s.id]);
    result.push({...s,topics});
  }
  res.json({subjects:result});
});

app.get("/api/topics/:id",auth,async(req,res)=>{
  const topic=await get(`SELECT t.id,t.name,t.slug,t.subtitle,s.id AS subject_id,s.name AS subject_name FROM topics t JOIN subjects s ON s.id=t.subject_id WHERE t.id=?`,[Number(req.params.id)]);
  if(!topic)return res.status(404).json({message:"Topic not found."});
  const source=subjects.flatMap(s=>s.topics.map(t=>({...t,subject:s.name}))).find(t=>t.name===topic.name&&t.subject===topic.subject_name);
  if(!source)return res.status(404).json({message:"Topic content not found."});
  const levels=await all(`SELECT difficulty,MAX(score*1.0/NULLIF(total,0)) AS ratio,MAX(completed_at) AS completed_at FROM quiz_attempts WHERE user_id=? AND topic_id=? AND completed_at IS NOT NULL GROUP BY difficulty`,[req.user.id,topic.id]);
  res.json({topic:{...topic,facts:source.facts,levels}});
});

app.get("/api/dashboard",auth,async(req,res)=>{
  const userId=req.user.id;
  const attempts=await all(`SELECT a.id,a.score,a.total,a.difficulty,a.completed_at,s.name AS subject,t.name AS topic FROM quiz_attempts a JOIN subjects s ON s.id=a.subject_id LEFT JOIN topics t ON t.id=a.topic_id WHERE a.user_id=? AND a.completed_at IS NOT NULL ORDER BY a.completed_at DESC LIMIT 8`,[userId]);
  const overall=await get(`SELECT COALESCE(SUM(score),0) score,COALESCE(SUM(total),0) total,COUNT(*) quizzes FROM quiz_attempts WHERE user_id=? AND completed_at IS NOT NULL`,[userId]);
  const subjectsRows=await all(`SELECT s.id,s.name,COALESCE(SUM(a.score),0) score,COALESCE(SUM(a.total),0) total FROM subjects s LEFT JOIN quiz_attempts a ON a.subject_id=s.id AND a.user_id=? AND a.completed_at IS NOT NULL GROUP BY s.id ORDER BY s.id`,[userId]);
  const performance=subjectsRows.map(s=>({...s,accuracy:s.total?Math.round(s.score/s.total*100):0}));
  const accuracy=overall.total?Math.round(overall.score/overall.total*100):0;
  let streak=0; const days=await all(`SELECT DISTINCT date(completed_at) day FROM quiz_attempts WHERE user_id=? AND completed_at IS NOT NULL ORDER BY day DESC`,[userId]);
  if(days.length){streak=1;for(let i=1;i<days.length;i++){const diff=Math.round((new Date(days[i-1].day)-new Date(days[i].day))/86400000);if(diff===1)streak++;else break;}}
  const weakest=[...performance].sort((a,b)=>a.accuracy-b.accuracy)[0]||null;
  res.json({user:{id:req.user.id,name:req.user.name,email:req.user.email},stats:{accuracy,quizzes:overall.quizzes,questions:overall.total,streak},topics:performance,recent:attempts,recommendation:weakest&&weakest.total?`Focus on ${weakest.name} — your current accuracy is ${weakest.accuracy}%.`:`Start a topic quiz to receive a personalized recommendation.`});
});

function levelOrder(level){return {Easy:1,Medium:2,Hard:3}[level]||1;}
async function levelUnlocked(userId,topicId,difficulty){
  const order=levelOrder(difficulty); if(order===1)return true;
  const previous=order===2?"Easy":"Medium";
  const row=await get(`SELECT score,total FROM quiz_attempts WHERE user_id=? AND topic_id=? AND difficulty=? AND completed_at IS NOT NULL ORDER BY completed_at DESC LIMIT 1`,[userId,topicId,previous]);
  return !!row && row.score>=8;
}

app.post("/api/quiz/start",auth,async(req,res)=>{
  try{
    const topicId=Number(req.body.topicId); const difficulty=String(req.body.difficulty||"Easy");
    if(!topicId||!["Easy","Medium","Hard"].includes(difficulty))return res.status(400).json({message:"Choose a topic and quiz level."});
    const topic=await get(`SELECT * FROM topics WHERE id=?`,[topicId]);
    if(!topic)return res.status(404).json({message:"Topic not found."});
    if(!(await levelUnlocked(req.user.id,topicId,difficulty)))return res.status(403).json({message:`Pass the previous level with at least 8/10 before unlocking ${difficulty}.`});

    const last=await get(`SELECT id FROM quiz_attempts WHERE user_id=? AND topic_id=? AND difficulty=? AND completed_at IS NOT NULL ORDER BY completed_at DESC LIMIT 1`,[req.user.id,topicId,difficulty]);
    let exclude=[];
    if(last){const used=await all(`SELECT question_id FROM attempt_answers WHERE attempt_id=?`,[last.id]);exclude=used.map(x=>x.question_id);}
    const rows=exclude.length
      ? await all(`SELECT id,question_text,option_a,option_b,option_c,option_d,difficulty,concept,correct_option,explanation FROM questions WHERE topic_id=? AND difficulty=? AND id NOT IN (${exclude.map(()=>'?').join(',')}) ORDER BY RANDOM() LIMIT 10`,[topicId,difficulty,...exclude])
      : await all(`SELECT id,question_text,option_a,option_b,option_c,option_d,difficulty,concept,correct_option,explanation FROM questions WHERE topic_id=? AND difficulty=? ORDER BY RANDOM() LIMIT 10`,[topicId,difficulty]);
    if(rows.length<10)return res.status(500).json({message:"The question pool for this level is incomplete. Please restart the project so the latest question bank can be seeded."});
    const attempt=await run(`INSERT INTO quiz_attempts(user_id,subject_id,topic_id,score,total,difficulty) VALUES(?,?,?,?,?,?)`,[req.user.id,topic.subject_id,topicId,0,10,difficulty]);
    res.json({attemptId:attempt.id,topicId,topicName:topic.name,difficulty,questions:rows});
  }catch(err){console.error(err);res.status(500).json({message:"Could not start quiz."});}
});

app.post("/api/quiz/:attemptId/submit",auth,async(req,res)=>{
  try{
    const attempt=await get(`SELECT * FROM quiz_attempts WHERE id=? AND user_id=?`,[Number(req.params.attemptId),req.user.id]);
    if(!attempt)return res.status(404).json({message:"Quiz attempt not found."});
    if(await get(`SELECT id FROM attempt_answers WHERE attempt_id=? LIMIT 1`,[attempt.id]))return res.status(409).json({message:"This quiz has already been submitted."});
    const answers=Array.isArray(req.body.answers)?req.body.answers:[];let score=0;const results=[];
    for(const item of answers){
      const q=await get(`SELECT * FROM questions WHERE id=?`,[Number(item.questionId)]);if(!q)continue;
      const selected=String(item.selectedOption||"").toUpperCase();const correct=selected===q.correct_option;if(correct)score++;
      await run(`INSERT INTO attempt_answers(attempt_id,question_id,selected_option,is_correct) VALUES(?,?,?,?)`,[attempt.id,q.id,selected||null,correct?1:0]);
      results.push({questionId:q.id,question:q.question_text,selectedOption:selected,correctOption:q.correct_option,isCorrect:correct,explanation:q.explanation,concept:q.concept});
    }
    await run(`UPDATE quiz_attempts SET score=?,total=?,completed_at=CURRENT_TIMESTAMP WHERE id=?`,[score,10,attempt.id]);
    res.json({attemptId:attempt.id,score,total:10,passed:score>=8,accuracy:score*10,results});
  }catch(err){console.error(err);res.status(500).json({message:"Could not submit quiz."});}
});

app.get("/api/results/:attemptId",auth,async(req,res)=>{
  const attempt=await get(`SELECT a.*,s.name subject,t.name topic FROM quiz_attempts a JOIN subjects s ON s.id=a.subject_id LEFT JOIN topics t ON t.id=a.topic_id WHERE a.id=? AND a.user_id=?`,[Number(req.params.attemptId),req.user.id]);
  if(!attempt)return res.status(404).json({message:"Result not found."});
  const answers=await all(`SELECT aa.*,q.question_text,q.correct_option,q.explanation,q.concept FROM attempt_answers aa JOIN questions q ON q.id=aa.question_id WHERE aa.attempt_id=? ORDER BY aa.id`,[attempt.id]);
  const levels=await all(`SELECT difficulty,score,total,completed_at FROM quiz_attempts WHERE user_id=? AND topic_id=? AND completed_at IS NOT NULL ORDER BY completed_at DESC`,[req.user.id,attempt.topic_id]);
  const latest={};for(const l of levels){if(!latest[l.difficulty])latest[l.difficulty]=l;}
  const weak=await all(`SELECT q.concept,COUNT(*) wrong_count FROM attempt_answers aa JOIN questions q ON q.id=aa.question_id WHERE aa.attempt_id=? AND aa.is_correct=0 GROUP BY q.concept ORDER BY wrong_count DESC`,[attempt.id]);
  res.json({attempt,passed:attempt.score>=8,answers:answers.map(a=>({question:a.question_text,selectedOption:a.selected_option,correctOption:a.correct_option,isCorrect:Boolean(a.is_correct),explanation:a.explanation,concept:a.concept})),levels:["Easy","Medium","Hard"].map(d=>({difficulty:d,...(latest[d]||{score:null,total:10,completed_at:null}),unlocked:d==="Easy"||d==="Medium"?(d==="Easy"||!!latest.Easy&&latest.Easy.score>=8):!!latest.Medium&&latest.Medium.score>=8})),weakAreas:weak});
});

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
initDatabase().then(()=>app.listen(PORT,()=>console.log(`ExamPrep is running at http://localhost:${PORT}`))).catch(err=>{console.error("Database initialization failed:",err);process.exit(1);});
