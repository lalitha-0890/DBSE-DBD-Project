async function loadDashboard(){
 if(!requireLogin())return;
 try{
  const data=await api('/dashboard');
  document.getElementById('welcomeName').textContent=data.user.name;document.getElementById('accuracy').textContent=`${data.stats.accuracy}%`;document.getElementById('quizCount').textContent=data.stats.quizzes;document.getElementById('questionCount').textContent=data.stats.questions;document.getElementById('streak').textContent=`${data.stats.streak} day${data.stats.streak===1?'':'s'}`;document.getElementById('recommendation').textContent=data.recommendation;
  document.getElementById('topics').innerHTML=data.topics.map(t=>`<div class="topic"><div class="topic-row"><span>${escapeHtml(t.name)}</span><span>${t.accuracy}%</span></div><div class="progress"><span style="width:${t.accuracy}%"></span></div></div>`).join('');
  document.getElementById('activity').innerHTML=data.recent.length?data.recent.map(a=>`<div class="activity"><div><strong>${escapeHtml(a.topic||a.subject)}</strong><small>${escapeHtml(a.subject)} • ${a.difficulty} • ${new Date(a.completed_at).toLocaleDateString()}</small></div><strong>${Math.round(a.score/a.total*100)}%</strong></div>`).join(''):'<p class="muted">No quiz attempts yet. Start learning below.</p>';
  const subjects=await api('/subjects');
  document.getElementById('subjectList').innerHTML=subjects.subjects.map(s=>`<article class="subject-card"><button class="subject-header" onclick="toggleSubject(${s.id})"><span class="subject-icon">${s.icon}</span><span class="subject-info"><strong>${escapeHtml(s.name)}</strong><small>${escapeHtml(s.description)}</small></span><span class="chevron" id="chevron-${s.id}">⌄</span></button><div class="topic-dropdown" id="subject-${s.id}">${s.topics.map(t=>`<a class="topic-option" href="/pages/topic.html?topic=${t.id}"><span class="topic-number">${String(t.id).padStart(2,'0')}</span><span><strong>${escapeHtml(t.name)}</strong><small>${escapeHtml(t.subtitle)}</small></span><span>→</span></a>`).join('')}</div></article>`).join('');
 }catch(err){if(token())alert(err.message);}
}
function toggleSubject(id){const box=document.getElementById(`subject-${id}`);const open=box.classList.toggle('open');document.getElementById(`chevron-${id}`).classList.toggle('rotate',open);}
function escapeHtml(str){return String(str).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));}
document.addEventListener('DOMContentLoaded',loadDashboard);
