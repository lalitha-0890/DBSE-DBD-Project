function togglePassword(id, button) {
  const input = document.getElementById(id);
  if (input.type === "password") {
    input.type = "text";
    button.textContent = "Hide";
  } else {
    input.type = "password";
    button.textContent = "Show";
  }
}

function showAuthMessage(message, type = "error") {
  const box = document.getElementById("authMessage");
  if (!box) return;
  box.textContent = message;
  box.className = `alert show ${type}`;
}

async function register(e) {
  e.preventDefault();
  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;
  const confirm = document.getElementById("confirm").value;

  if (password !== confirm) {
    showAuthMessage("Passwords do not match.");
    return;
  }

  try {
    const data = await api("/auth/register", {
      method: "POST",
      body: JSON.stringify({ name, email, password })
    });
    saveSession(data);
    location.href = "/pages/dashboard.html";
  } catch (err) {
    showAuthMessage(err.message);
  }
}

async function login(e) {
  e.preventDefault();
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;

  try {
    const data = await api("/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, password })
    });
    saveSession(data);
    location.href = "/pages/dashboard.html";
  } catch (err) {
    showAuthMessage(err.message);
  }
}
