const API = "/api";

function token() {
  return localStorage.getItem("examprep_token");
}

function saveSession(data) {
  localStorage.setItem("examprep_token", data.token);
  localStorage.setItem("examprep_user", JSON.stringify(data.user));
}

function clearSession() {
  localStorage.removeItem("examprep_token");
  localStorage.removeItem("examprep_user");
}

function applyTheme(theme) {
  const selected = theme || localStorage.getItem("examprep_theme") || "lavender";
  document.documentElement.dataset.theme = selected;
}

function saveUser(user) {
  localStorage.setItem("examprep_user", JSON.stringify(user));
}

function getUser() {
  try { return JSON.parse(localStorage.getItem("examprep_user") || "null"); }
  catch { return null; }
}

async function api(url, options = {}) {
  const headers = { "Content-Type": "application/json", ...(options.headers || {}) };
  if (token()) headers.Authorization = `Bearer ${token()}`;

  const response = await fetch(API + url, { ...options, headers });
  let data = {};
  try { data = await response.json(); } catch {}
  if (!response.ok) {
    if (response.status === 401) {
      clearSession();
      if (!location.pathname.endsWith("login.html")) location.href = "/pages/login.html";
    }
    throw new Error(data.message || "Something went wrong.");
  }
  return data;
}

function requireLogin() {
  if (!token()) {
    location.href = "/pages/login.html";
    return false;
  }
  return true;
}

function logout() {
  clearSession();
  location.href = "/";
}

document.addEventListener("DOMContentLoaded", () => {
  applyTheme();
  const user = getUser();
  document.querySelectorAll("[data-user-name]").forEach(el => {
    el.textContent = user?.name || "Student";
  });

  const menu = document.querySelector(".menu");
  const nav = document.querySelector(".nav-links");
  if (menu && nav) {
    menu.addEventListener("click", () => {
      nav.classList.toggle("mobile-open");
    });
  }
});
