let topicData=null, flashIndex=0, flashFlipped=false;
const params=new URLSearchParams(location.search);const topicId=params.get('topic');
function key(){return `examprep_important_${topicId}`;}
function important(){try{return JSON.parse(localStorage.getItem(key())||'[]')}catch{return[]}}
async function loadTopic(){
 if(!requireLogin())return;
 if(!topicId){location.href='/pages/dashboard.html';return;}
 try{const data=await api(`/topics/${topicId}`);topicData=data.topic;renderTopic();}catch(e){alert(e.message);location.href='/pages/dashboard.html';}
}
function subjectVisual(subject, topic){
 const s=subject.toLowerCase();
 if(s.includes('operating')) return {label:'OS service flow',nodes:['Application','System Call','Kernel','Hardware'],note:'Programs request services from the kernel instead of accessing protected hardware directly.'};
 if(s.includes('backend')) return {label:'Backend request flow',nodes:['Client','API','Service Logic','Database'],note:'A request moves through the API and application logic before data is stored or returned.'};
 if(s.includes('data structures')) return {label:'Algorithmic thinking',nodes:['Input','Data Structure','Algorithm','Output'],note:'The data representation and algorithm work together to transform input into a useful result.'};
 return {label:'ML lifecycle',nodes:['Data','Features','Model','Evaluation','Deployment'],note:'A model learns from prepared data, is evaluated on unseen data, and can then be deployed.'};
}
function conceptBullets(f){
 return `<ul class="concept-bullets"><li><strong>Core idea:</strong> ${escapeHtml(f[1])}</li><li><strong>Practical view:</strong> ${escapeHtml(f[2])}</li></ul>`;
}
function renderTopic(){
 document.getElementById('subjectName').textContent=topicData.subject_name;document.getElementById('topicName').textContent=topicData.name;
 document.getElementById('topicTitle').textContent=topicData.name;document.getElementById('topicSubtitle').textContent=topicData.subtitle;
 const saved=important();
 document.getElementById('notesList').innerHTML=topicData.facts.map((f,i)=>`<article class="note-block concept-note" id="note-${i}"><div class="note-head"><div class="note-title-wrap"><span class="note-number">${String(i+1).padStart(2,'0')}</span><div><span class="concept-label">CONCEPT ${String(i+1).padStart(2,'0')}</span><h3>${escapeHtml(f[0])}</h3></div></div><button class="star-btn ${saved.includes(i)?'active':''}" aria-label="Mark important" onclick="toggleImportant(${i})">${saved.includes(i)?'★':'☆'}</button></div>${conceptBullets(f)}<div class="example"><span>APPLICATION / EXAMPLE</span>${escapeHtml(f[2])}</div></article>`).join('');
 document.getElementById('quickRevision').innerHTML=topicData.facts.map((f,i)=>`<div class="quick-card"><span class="quick-index">${String(i+1).padStart(2,'0')}</span><div><strong>${escapeHtml(f[0])}</strong><span>${escapeHtml(f[1])}</span></div></div>`).join('');
 const visual=subjectVisual(topicData.subject_name,topicData.name);
 document.getElementById('visualFlow').innerHTML=`<div class="diagram-caption"><span>${escapeHtml(visual.label)}</span><p>${escapeHtml(visual.note)}</p></div><div class="concept-flow">${visual.nodes.map((n,i)=>`<div class="flow-step"><div class="flow-icon">${i+1}</div><strong>${escapeHtml(n)}</strong></div>${i<visual.nodes.length-1?'<div class="flow-arrow">→</div>':''}`).join('')}</div><div class="topic-visual-branches">${topicData.facts.slice(0,5).map((f,i)=>`<div class="visual-branch"><div class="visual-dot">${i+1}</div><div><strong>${escapeHtml(f[0])}</strong><span>${escapeHtml(f[1])}</span></div></div>`).join('')}</div>`;
 document.getElementById('mindMap').innerHTML=`<div class="map-root">${escapeHtml(topicData.name)}</div><div class="map-children">${topicData.facts.slice(0,8).map((f,i)=>`<div class="map-child"><span>${String(i+1).padStart(2,'0')}</span>${escapeHtml(f[0])}</div>`).join('')}</div>`;
 updateImportantCount();renderFlashcard();
}
function toggleImportant(i){let arr=important();arr=arr.includes(i)?arr.filter(x=>x!==i):[...arr,i];localStorage.setItem(key(),JSON.stringify(arr));renderTopic();}
function toggleTopicImportant(){const all=topicData.facts.map((_,i)=>i);const arr=important();localStorage.setItem(key(),JSON.stringify(arr.length===all.length?[]:all));renderTopic();}
function updateImportantCount(){const n=important().length;document.getElementById('importantCount').textContent=`${n} concept${n===1?'':'s'} saved`;document.getElementById('importantToggle').textContent=n===topicData.facts.length?'★ All concepts saved':'☆ Save important concepts';}
function showImportantNotes(){const arr=important();document.getElementById('importantNotesList').innerHTML=arr.length?arr.map(i=>`<div class="saved-note"><strong>${escapeHtml(topicData.facts[i][0])}</strong><p>${escapeHtml(topicData.facts[i][1])}</p><button onclick="document.getElementById('note-${i}').scrollIntoView({behavior:'smooth'});closeImportantNotes()">Open concept</button></div>`).join(''):'<p class="muted">No important concepts yet. Tap ☆ beside a concept to save it.</p>';document.getElementById('importantModal').classList.remove('hidden');}
function closeImportantNotes(){document.getElementById('importantModal').classList.add('hidden');}
function renderFlashcard(){const f=topicData.facts[flashIndex];flashFlipped=false;document.getElementById('flashcard').classList.remove('flipped');document.getElementById('flashcard').innerHTML=`<div class="flash-front"><span>CONCEPT</span><strong>${escapeHtml(f[0])}</strong><small>Click to reveal the explanation</small></div><div class="flash-back"><span>KEY IDEA</span><p>${escapeHtml(f[1])}</p></div>`;document.getElementById('cardCount').textContent=`${flashIndex+1} / ${topicData.facts.length}`;}
function flipFlashcard(){flashFlipped=!flashFlipped;document.getElementById('flashcard').classList.toggle('flipped',flashFlipped);}
function nextCard(){flashIndex=(flashIndex+1)%topicData.facts.length;renderFlashcard();}
function prevCard(){flashIndex=(flashIndex-1+topicData.facts.length)%topicData.facts.length;renderFlashcard();}
function openQuizLevels(){const levels=topicData.levels||[];document.getElementById('levelChoices').innerHTML=['Easy','Medium','Hard'].map((d)=>{const l=levels.find(x=>x.difficulty===d);const unlocked=d==='Easy'||(d==='Medium'&&levels.some(x=>x.difficulty==='Easy'&&x.ratio>=.8))||(d==='Hard'&&levels.some(x=>x.difficulty==='Medium'&&x.ratio>=.8));const label=l?`${Math.round(l.ratio*10)}/10 latest`:'Not attempted';return `<button class="level-choice ${unlocked?'':'locked'}" ${unlocked?'':'disabled'} onclick="startLevel('${d}')"><span>${d}</span><small>${unlocked?'Available':'🔒 Pass previous level'}</small><em>${label}</em></button>`;}).join('');document.getElementById('levelModal').classList.remove('hidden');}
function closeQuizLevels(){document.getElementById('levelModal').classList.add('hidden');}
async function startLevel(level){try{const data=await api('/quiz/start',{method:'POST',body:JSON.stringify({topicId:Number(topicId),difficulty:level})});sessionStorage.setItem('quiz_session',JSON.stringify(data));location.href='/pages/quiz.html';}catch(e){alert(e.message);}}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));}
document.addEventListener('DOMContentLoaded',loadTopic);
