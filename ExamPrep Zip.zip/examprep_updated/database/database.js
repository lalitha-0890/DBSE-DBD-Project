const sqlite3 = require("sqlite3").verbose();
const bcrypt = require("bcryptjs");
const path = require("path");
const { subjects } = require("../content");

const dbPath = path.join(__dirname, "examprep.db");
const db = new sqlite3.Database(dbPath);

function run(sql, params = []) {
  return new Promise((resolve, reject) => db.run(sql, params, function (err) {
    if (err) reject(err); else resolve({ id: this.lastID, changes: this.changes });
  }));
}
function get(sql, params = []) {
  return new Promise((resolve, reject) => db.get(sql, params, (err, row) => err ? reject(err) : resolve(row)));
}
function all(sql, params = []) {
  return new Promise((resolve, reject) => db.all(sql, params, (err, rows) => err ? reject(err) : resolve(rows)));
}
async function hasColumn(table, column) {
  const rows = await all(`PRAGMA table_info(${table})`);
  return rows.some(r => r.name === column);
}

function makeQuestions(topicId, subjectId, topic) {
  const rows = [];
  const letters = ["A","B","C","D"];
  const shuffle = arr => [...arr].sort(() => Math.random() - 0.5);
  topic.facts.forEach((fact, index) => {
    const [concept, definition, application] = fact;
    const others = topic.facts.filter((_, i) => i !== index);
    const distractDef = others.slice(0,3).map(x => x[1]);
    const distractApp = others.slice(0,3).map(x => x[2]);
    const variants = [
      {
        Easy: [`Which statement best describes ${concept}?`, definition, distractDef, `The key idea is that ${concept.toLowerCase()} has a specific role in this topic.`],
        Medium: [`Which situation best demonstrates ${concept}?`, application, distractApp, `This scenario applies the defining role of ${concept.toLowerCase()} in practice.`],
        Hard: [`A student is reviewing ${concept}. Which interpretation is most appropriate?`, definition, distractDef, `The correct interpretation follows the core meaning of ${concept.toLowerCase()}.`]
      },
      {
        Easy: [`What is the main purpose of ${concept}?`, definition, distractDef, `${concept} is identified by this core purpose.`],
        Medium: [`In a practical system, which outcome is most closely associated with ${concept}?`, application, distractApp, `The example is directly connected to how ${concept.toLowerCase()} is used.`],
        Hard: [`Which choice would be the strongest explanation of ${concept} in an exam answer?`, definition, distractDef, `The strongest explanation states the defining property rather than an unrelated concept.`]
      }
    ];
    for (const difficulty of ["Easy","Medium","Hard"]) {
      variants.forEach((variant, vIndex) => {
        const spec = variant[difficulty];
        const options = shuffle([spec[1], ...spec[2]]);
        const correct = letters[options.indexOf(spec[1])];
        rows.push({
          subjectId, topicId, concept, difficulty,
          question_text: spec[0], option_a: options[0], option_b: options[1], option_c: options[2], option_d: options[3],
          correct_option: correct, explanation: spec[3]
        });
      });
    }
  });
  return rows;
}

async function initDatabase() {
  await run(`PRAGMA foreign_keys = ON`);
  await run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, username TEXT UNIQUE, email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL, profile_pic TEXT, theme TEXT DEFAULT 'lavender', created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);
  if (!(await hasColumn("users","username"))) await run(`ALTER TABLE users ADD COLUMN username TEXT`);
  if (!(await hasColumn("users","profile_pic"))) await run(`ALTER TABLE users ADD COLUMN profile_pic TEXT`);
  if (!(await hasColumn("users","theme"))) await run(`ALTER TABLE users ADD COLUMN theme TEXT DEFAULT 'lavender'`);
  const usersWithoutUsername=await all(`SELECT id,name,email FROM users WHERE username IS NULL OR username=''`);
  for(const u of usersWithoutUsername){
    let base=(u.name||u.email.split("@")[0]).toLowerCase().replace(/[^a-z0-9]+/g,".").replace(/^\.|\.$/g,"").slice(0,20)||`student${u.id}`;
    let candidate=base, n=1;
    while(await get(`SELECT id FROM users WHERE username=? AND id<>?`,[candidate,u.id])) candidate=`${base}${++n}`;
    await run(`UPDATE users SET username=? WHERE id=?`,[candidate,u.id]);
  }
  await run(`CREATE TABLE IF NOT EXISTS subjects (
    id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, description TEXT NOT NULL, icon TEXT NOT NULL
  )`);
  await run(`CREATE TABLE IF NOT EXISTS topics (
    id INTEGER PRIMARY KEY AUTOINCREMENT, subject_id INTEGER NOT NULL, name TEXT NOT NULL,
    slug TEXT NOT NULL, subtitle TEXT NOT NULL, UNIQUE(subject_id,name),
    FOREIGN KEY(subject_id) REFERENCES subjects(id) ON DELETE CASCADE
  )`);
  await run(`CREATE TABLE IF NOT EXISTS questions (
    id INTEGER PRIMARY KEY AUTOINCREMENT, subject_id INTEGER NOT NULL, topic_id INTEGER,
    concept TEXT, question_text TEXT NOT NULL, option_a TEXT NOT NULL, option_b TEXT NOT NULL,
    option_c TEXT NOT NULL, option_d TEXT NOT NULL, correct_option TEXT NOT NULL,
    explanation TEXT NOT NULL, difficulty TEXT NOT NULL CHECK(difficulty IN ('Easy','Medium','Hard')),
    FOREIGN KEY(subject_id) REFERENCES subjects(id) ON DELETE CASCADE,
    FOREIGN KEY(topic_id) REFERENCES topics(id) ON DELETE CASCADE
  )`);
  await run(`CREATE TABLE IF NOT EXISTS quiz_attempts (
    id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, subject_id INTEGER NOT NULL,
    topic_id INTEGER, score INTEGER NOT NULL, total INTEGER NOT NULL, difficulty TEXT NOT NULL,
    started_at DATETIME DEFAULT CURRENT_TIMESTAMP, completed_at DATETIME,
    FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY(subject_id) REFERENCES subjects(id) ON DELETE CASCADE,
    FOREIGN KEY(topic_id) REFERENCES topics(id) ON DELETE SET NULL
  )`);
  await run(`CREATE TABLE IF NOT EXISTS attempt_answers (
    id INTEGER PRIMARY KEY AUTOINCREMENT, attempt_id INTEGER NOT NULL, question_id INTEGER NOT NULL,
    selected_option TEXT, is_correct INTEGER NOT NULL,
    FOREIGN KEY(attempt_id) REFERENCES quiz_attempts(id) ON DELETE CASCADE,
    FOREIGN KEY(question_id) REFERENCES questions(id) ON DELETE CASCADE
  )`);

  if (!(await hasColumn("questions","topic_id"))) await run(`ALTER TABLE questions ADD COLUMN topic_id INTEGER`);
  if (!(await hasColumn("questions","concept"))) await run(`ALTER TABLE questions ADD COLUMN concept TEXT`);
  if (!(await hasColumn("quiz_attempts","topic_id"))) await run(`ALTER TABLE quiz_attempts ADD COLUMN topic_id INTEGER`);

  // Sync the four subject names with the current project.
  const desiredSubjects = subjects.map(s => [s.name,s.description,s.icon]);
  const legacyMap = {
    "Operating Systems":"Operating Systems and System Programming",
    "Database Systems":"Backend Development",
    "Data Structures":"Data Structures and Algorithms",
    "Computer Networks":"Machine Learning"
  };
  for (const [oldName,newName] of Object.entries(legacyMap)) {
    const old = await get(`SELECT id FROM subjects WHERE name=?`,[oldName]);
    const newExists = await get(`SELECT id FROM subjects WHERE name=?`,[newName]);
    if (old && !newExists) await run(`UPDATE subjects SET name=? WHERE id=?`,[newName,old.id]);
    else if (old && newExists && old.id !== newExists.id) await run(`DELETE FROM subjects WHERE id=?`,[old.id]);
  }
  for (const [name,description,icon] of desiredSubjects) {
    await run(`INSERT OR IGNORE INTO subjects(name,description,icon) VALUES(?,?,?)`,[name,description,icon]);
    await run(`UPDATE subjects SET description=?,icon=? WHERE name=?`,[description,icon,name]);
  }

  const subjectRows = await all(`SELECT id,name FROM subjects`);
  const subjectIdByName = Object.fromEntries(subjectRows.map(s => [s.name,s.id]));

  for (const subject of subjects) {
    const subjectId = subjectIdByName[subject.name];
    for (const topic of subject.topics) {
      await run(`INSERT OR IGNORE INTO topics(subject_id,name,slug,subtitle) VALUES(?,?,?,?)`,[subjectId,topic.name,topic.slug,topic.subtitle]);
      await run(`UPDATE topics SET slug=?,subtitle=? WHERE subject_id=? AND name=?`,[topic.slug,topic.subtitle,subjectId,topic.name]);
    }
  }

  // Seed a full question pool: 20 questions per difficulty per topic. This allows a 10-question quiz plus a different 10-question re-attempt.
  for (const subject of subjects) {
    const subjectId = subjectIdByName[subject.name];
    for (const topic of subject.topics) {
      const topicRow = await get(`SELECT id FROM topics WHERE subject_id=? AND name=?`,[subjectId,topic.name]);
      const count = await get(`SELECT COUNT(*) AS count FROM questions WHERE topic_id=?`,[topicRow.id]);
      if (!count.count) {
        const rows = makeQuestions(topicRow.id,subjectId,topic);
        for (const q of rows) {
          await run(`INSERT INTO questions(subject_id,topic_id,concept,question_text,option_a,option_b,option_c,option_d,correct_option,explanation,difficulty)
            VALUES(?,?,?,?,?,?,?,?,?,?,?)`,[q.subjectId,q.topicId,q.concept,q.question_text,q.option_a,q.option_b,q.option_c,q.option_d,q.correct_option,q.explanation,q.difficulty]);
        }
      }
    }
  }

  const demo = await get(`SELECT id FROM users WHERE email=?`,["demo@examprep.com"]);
  if (!demo) {
    const hash = await bcrypt.hash("demo123",10);
    await run(`INSERT INTO users(name,username,email,password_hash) VALUES(?,?,?,?)`,["Demo Student","demo.student","demo@examprep.com",hash]);
  }
}

module.exports = { db, run, get, all, initDatabase };
