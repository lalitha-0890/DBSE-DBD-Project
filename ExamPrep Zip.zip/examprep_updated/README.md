# ExamPrep Full-Stack Website

A student exam-preparation web application with a purple/lavender theme, subject → topic learning flow, one-shot notes, flash cards, mind maps, important-note marking, and 3-level quizzes.

## Run locally

1. Open this folder in VS Code or a terminal.
2. First time only:
   `npm install`
3. Start the server:
   `npm start`
4. Open:
   `http://localhost:3000`
5. Keep the terminal open while using the site.
6. Stop the server with `Ctrl + C`.

## Demo account

- Email: `demo@examprep.com`
- Password: `demo123`

## Learning flow

Dashboard → Subject → Topic → One-Shot Notes → Flash Cards / Mind Map / Important Notes → Take Quiz → Easy / Medium / Hard → Results & Weak Areas

Each level contains 10 questions and requires 8/10 to pass. Medium unlocks after passing Easy; Hard unlocks after passing Medium. A failed level can be re-attempted, and the immediate re-attempt pulls a different set of questions from the topic's question pool.

## Subjects

- Operating Systems and System Programming
- Backend Development
- Data Structures and Algorithms
- Machine Learning

Topic content is currently seeded from the topic list provided for the project and can be extended later.
